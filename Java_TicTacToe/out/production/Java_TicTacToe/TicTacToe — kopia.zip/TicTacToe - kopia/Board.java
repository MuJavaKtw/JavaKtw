package TicTacToe;

import java.io.IOException;
import java.util.List;

public class Board {

    public boolean setInput(int[][] board) throws IOException {


        for (int y = 0; y <= 2; y++) {
            for (int x = 0; x <= 2; x++) {
                if (board[x][y] == 0) {
                    System.out.print(" ");
                } else if (board[x][y] == 1) {
                    System.out.print("O");
                } else if (board[x][y] == 2) {
                    System.out.print("X");
                }
                if (x == 2) {
                    continue;
                }
                System.out.print("|");
            }
            System.out.println();
            if (y != 2) {
                System.out.print("-----");
                System.out.println();
            }
        }
        Winner w = new Winner();
        boolean winner = w.getWinner(board);

        return winner;
    }
}
