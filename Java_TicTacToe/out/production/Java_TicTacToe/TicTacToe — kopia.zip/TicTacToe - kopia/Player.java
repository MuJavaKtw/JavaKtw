package TicTacToe;

public class Player {

    public int changePlayer(int startChoice) {

        if (startChoice == 1) {
            startChoice = 2;
        } else {
            startChoice = 1;
        }
        return startChoice;
    }
}

