package TicTacToe;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        boolean noWinner = true;
        int[][] board = new int[3][3];
        boolean validation = false;

        BoardCoordinates boardCoordinates = new BoardCoordinates();
        boardCoordinates.board();

        Start start = new Start();
        int choice = start.getChoice();

        // Główna pętla - jeśli nie wyłonimy zwycięzcy to będzie działać
        while (noWinner) {
            Hit hit = new Hit();
            Board b = new Board();

            int[][] hitInput = hit.getInput(choice);

            while (validation) {
                System.out.println("Podaj pole");
                if (hit == null || !hit.matches("\\d([,\\s])\\d")) {
                    System.out.println("Podałeś złe współrzędne");
                    validation = true;
                } else {
                    validation = false;
                }
            }


            //sprawdzenie czy współrzędne nie są już zajęte
            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board[i].length; j++) {
                    if (hitInput[i][j] != 0 && board[i][j] == 0) {
                        board[i][j] = hitInput[i][j];
                    }
                }
            }

            if (choice == 1) {
                choice = 2;
            } else {
                choice = 1;
            }

            noWinner = b.setInput(board);
        }
    }
}



