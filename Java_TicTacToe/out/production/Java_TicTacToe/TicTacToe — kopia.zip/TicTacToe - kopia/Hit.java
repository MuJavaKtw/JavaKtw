package TicTacToe;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Hit {

    int[][] board = new int[3][3];

    public int[][] getInput(int choice) throws IOException {

        boolean validation = true;
        String hit = "";

        // walidacja strzału - dostosowanie do wyrażenia refularnego typu "d 1"
        while (validation) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Podaj pole");
            hit = br.readLine();
            if (hit == null || !hit.matches("\\d([,\\s])\\d")) {
                System.out.println("Podałeś złe współrzędne");
                validation = true;
            } else {
                validation = false;
            }
        }

        // wydzielenie ze strzału współrzędnych x oraz y
        String[] coordinates = hit.split(" ");
        int x = Integer.parseInt(coordinates[0]);
        int y = Integer.parseInt(coordinates[1]);

        // wpisanie strzału do tablicy [3] na [3]
        int[][] hitInput = new int[3][3];
        hitInput[x - 1][y - 1] = choice;

        // wpisanie strzału do tablicy głównej board
        /*
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (hitInput[i][j] != 0 && board[i][j] == 0) {
                    board[i][j] = hitInput[i][j];
                    continue;
                }
            }
        }
        System.out.println(board[0][0]);
        */


        return hitInput;
    }
}

