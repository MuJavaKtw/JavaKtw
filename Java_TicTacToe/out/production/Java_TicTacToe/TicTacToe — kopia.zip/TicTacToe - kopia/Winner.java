package TicTacToe;

public class Winner {

    public boolean winner(int winner) {

        if (winner == 1) {
            System.out.println("GRATULACJE - kółka wygrały");
            return false;
        } else {
            System.out.println("GRATULACJE - krzyżyki wygrały");
            return false;
        }
    }

    public boolean getWinner(int[][] board) {

        boolean row;
        boolean col;
        boolean diagonal1, diagonal2;

        //sprawdzenie wygranej w rzędach
        for (int i = 0; i < 3; i++) {
            col = (board[i][0] == (board[i][1]) && board[i][0] == (board[i][2]))  && board[i][0]!= 0;
            row = (board[0][i] == (board[1][i]) && board[0][i] == (board[2][i]))  && board[0][i]!= 0;
            diagonal1 = (board[0][0] == (board[1][1]) && board[0][0] == (board[2][2])) && board[1][1]!= 0;
            diagonal2 = (board[0][2] == (board[1][1]) && board[0][2] == (board[2][0])) && board[1][1]!= 0;
            //   (board[0][2] == (board[1][1]) && board[1][1] == (board[2][0]));
            if (col) {
                winner(board[i][0]);
                return false;
            } else if (row) {
                winner(board[0][i]);
                return false;
            } else if (diagonal1 || diagonal2) {
                winner(board[1][1]);
                return false;
            } else {
                return true;
            }
        }
        return true;
    }

}